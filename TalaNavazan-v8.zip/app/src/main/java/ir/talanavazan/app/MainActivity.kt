package ir.talanavazan.app

import android.app.*
import android.os.*
import android.graphics.*
import android.view.*
import android.widget.*
import android.speech.tts.TextToSpeech
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class MainActivity : Activity() {
    private val history = ArrayDeque<Double>()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var price: TextView; private lateinit var signal: TextView; private lateinit var metrics: TextView
    private lateinit var analyst: TextView; private lateinit var backtest: TextView; private lateinit var status: TextView
    private lateinit var chart: PriceChart; private lateinit var watch: TextView; private lateinit var marketList: LinearLayout
    private lateinit var trade: TextView; private lateinit var news: TextView; private lateinit var capitalInput: EditText
    private lateinit var searchInput: EditText
    private var tts: TextToSpeech? = null
    private var lastAnnounced = ""
    private var alerts = true
    private var allSymbols: List<MarketSymbol> = emptyList()
    private val refresh = object : Runnable { override fun run(){ fetchGold(); fetchMarketWatch(); handler.postDelayed(this, 60_000) } }
    private val catalogRefresh = object : Runnable { override fun run(){ fetchMarketWatch(); handler.postDelayed(this, 6 * 60 * 60 * 1000L) } }

    override fun onCreate(b: Bundle?) { super.onCreate(b); load(); ui(); channel(); initTts(); checkForPlayUpdate(); handler.post(refresh); handler.post(catalogRefresh) }
    override fun onDestroy(){ handler.removeCallbacks(refresh); handler.removeCallbacks(catalogRefresh); tts?.shutdown(); super.onDestroy() }

    private fun text(t:String, size:Float=15f, bold:Boolean=false)=TextView(this).apply{
        text=t; textSize=size; setTextColor(Color.rgb(28,31,38)); gravity=Gravity.RIGHT; setPadding(16,10,16,10)
        if(bold) setTypeface(typeface,1)
    }
    private fun card(title:String, view:View)=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); elevation=5f; setPadding(12,12,12,12)
        addView(text(title,13f,true)); addView(view); layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(7,7,7,7)}
    }
    private fun ui(){
        val scroll=ScrollView(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,10,8,24);setBackgroundColor(Color.rgb(245,247,250))}
        root.addView(text("طلا نوسان PRO",29f,true)); root.addView(text("تحلیل‌گر هوشمند چندبازاری — داده و فهرست نمادها خودکار به‌روز می‌شوند",15f))
        price=text("در حال دریافت قیمت...",27f,true); root.addView(card("طلای ۱۸ عیار / ۷۵۰",price))
        signal=text("🟡 صبر",30f,true); root.addView(card("سیگنال هوشمند",signal))
        capitalInput=EditText(this).apply{hint="سرمایه (تومان) مثال: 10000000";inputType=2;textSize=16f;gravity=Gravity.RIGHT;setPadding(16,12,16,12)}
        root.addView(card("💰 محاسبه معامله با سرمایه شما",capitalInput))
        trade=text("در انتظار تحلیل...",15f); root.addView(card("🎯 پیشنهاد معامله حرفه‌ای",trade))
        metrics=text("در حال محاسبه اندیکاتورها...",14f); root.addView(card("📊 داشبورد تکنیکال کامل",metrics))
        chart=PriceChart(this); chart.layoutParams=LinearLayout.LayoutParams(-1,390); root.addView(card("📈 نمودار",chart))
        analyst=text("در انتظار داده...",15f); root.addView(card("🧠 AI Analyst — تحلیل‌گر ترکیبی",analyst))
        news=text("در حال دریافت اخبار...",14f); root.addView(card("📰 فاندامنتال و اخبار",news))
        backtest=text("در انتظار تاریخچه...",14f); root.addView(card("🧪 بک‌تست + مدیریت ریسک",backtest))
        watch=text("طلا ۱۸: —\nدلار: —\nاونس: —",15f); root.addView(card("👁 دیده‌بان کلان",watch))

        searchInput=EditText(this).apply{hint="جستجوی نماد؛ مثل فولاد، فملی، شستا...";inputType=1;textSize=16f;gravity=Gravity.RIGHT;setPadding(16,12,16,12)}
        root.addView(card("🔎 جستجوی تمام نمادهای بازار",searchInput))
        marketList=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(card("📋 دیده‌بان بورس و فرابورس — بروزرسانی خودکار",marketList))
        searchInput.addTextChangedListener(SimpleWatcher{renderMarket(it)})

        val buttons=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val refreshBtn=Button(this).apply{text="🔄 بروزرسانی نمادها";setOnClickListener{fetchMarketWatch()}}
        val alert=Button(this).apply{text="🔔 هشدارها: روشن";setOnClickListener{alerts=!alerts;text=if(alerts)"🔔 هشدارها: روشن" else "🔕 هشدارها: خاموش"}}
        buttons.addView(refreshBtn,LinearLayout.LayoutParams(0,-2,1f)); buttons.addView(alert,LinearLayout.LayoutParams(0,-2,1f)); root.addView(buttons)
        status=text("اتصال...",12f); root.addView(status)
        root.addView(card("ℹ️ بروزرسانی برنامه",text("خود برنامه در صورت انتشار نسخه جدید روی Google Play از In-App Update استفاده می‌کند. داده‌ها و فهرست نمادها مستقل از نسخه برنامه و خودکار تازه می‌شوند.",12f)))
        scroll.addView(root); setContentView(scroll)
    }

    private fun fetchGold(){ Thread{
        try{
            val h=get("https://www.tgju.org/home")
            val g=extract(h,"طلای 18 عیار") ?: extract(h,"طلا ۱۸") ?: 0.0
            val d=extract(h,"دلار") ?: 0.0; val o=extract(h,"انس طلا") ?: 0.0
            runOnUiThread{ if(g>0) update(g,d,o); status.text="آخرین بروزرسانی: ${SimpleDateFormat("HH:mm:ss",Locale.US).format(Date())}"; fetchNews() }
        }catch(e:Exception){runOnUiThread{status.text="اتصال ناموفق؛ تلاش مجدد خودکار."}}
    }.start() }

    private fun fetchMarketWatch(){ Thread{
        try{
            val u="https://cdn.tsetmc.com/api/ClosingPrice/GetMarketWatch?market=0&paperTypes%5B0%5D=1&paperTypes%5B1%5D=2&paperTypes%5B2%5D=3&paperTypes%5B3%5D=4&paperTypes%5B4%5D=5&paperTypes%5B5%5D=6&paperTypes%5B6%5D=7&paperTypes%5B7%5D=8&paperTypes%5B8%5D=9&withBestLimits=false&hEven=0&RefID=0"
            val body=get(u); val root=JSONObject(body); val arr=root.optJSONArray("marketwatch") ?: JSONArray()
            val out=ArrayList<MarketSymbol>(arr.length())
            for(i in 0 until arr.length()){
                val x=arr.optJSONObject(i) ?: continue
                val code=x.optString("insCode"); val symbol=x.optString("lVal18AFC"); val name=x.optString("lVal30")
                if(code.isBlank() || symbol.isBlank()) continue
                val last=x.optDouble("pDrCotVal",x.optDouble("pl",0.0)); val close=x.optDouble("pClosing",x.optDouble("pc",0.0))
                val pct=x.optDouble("percent",x.optDouble("priceChangePercent",0.0)); val vol=x.optDouble("qTotTran5J",0.0); val value=x.optDouble("qTotCap",0.0)
                out.add(MarketSymbol(code,symbol,name,last,close,pct,vol,value))
            }
            if(out.isNotEmpty()){
                allSymbols=out.sortedBy{it.symbol}; saveCatalog(out)
                runOnUiThread{renderMarket(searchInput.text.toString()); status.text="${out.size} نماد از دیده‌بان بازار به‌روزرسانی شد — ${SimpleDateFormat("HH:mm:ss",Locale.US).format(Date())}"}
            }
        }catch(e:Exception){
            allSymbols=loadCatalog(); runOnUiThread{renderMarket(searchInput.text.toString()); status.text="داده بازار موقتاً در دسترس نیست؛ آخرین فهرست ذخیره‌شده نمایش داده شد."}
        }
    }.start() }

    private fun renderMarket(query:String){
        if(!::marketList.isInitialized)return
        marketList.removeAllViews(); val q=query.trim().lowercase(Locale.ROOT)
        val list=if(q.isBlank()) allSymbols.take(80) else allSymbols.filter{it.symbol.lowercase(Locale.ROOT).contains(q)||it.name.lowercase(Locale.ROOT).contains(q)}.take(120)
        if(list.isEmpty()){marketList.addView(text("نمادی پیدا نشد یا هنوز فهرست دریافت نشده است."));return}
        list.forEach { s ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(6,6,6,6)}
            val info=text("${s.symbol} — ${s.name}\nآخرین: ${fmt(s.last)} | پایانی: ${fmt(s.close)} | تغییر: ${String.format(Locale.US,"%.2f",s.pct)}%\nحجم: ${fmt(s.volume)} | ارزش: ${fmt(s.value)}",13f,true)
            row.addView(info,LinearLayout.LayoutParams(0,-2,1f))
            val btn=Button(this).apply{text="تحلیل";setOnClickListener{analyzeSymbol(s)}}
            row.addView(btn)
            marketList.addView(row)
            val line=View(this).apply{setBackgroundColor(Color.LTGRAY);layoutParams=LinearLayout.LayoutParams(-1,1)};marketList.addView(line)
        }
    }

    private fun analyzeSymbol(s:MarketSymbol){
        val vals=loadSymbolHistory(s.code).toMutableList(); if(vals.isEmpty() || vals.last()!=s.last) vals.add(s.last)
        saveSymbolHistory(s.code,vals.takeLast(5000)); val ind=Indicators(vals); val score=ind.score(); val sig=when{score>=72->"🟢 خرید";score<=28->"🔴 فروش";else->"🟡 صبر"}
        val msg="${s.symbol} — ${s.name}\nسیگنال: $sig | قدرت: $score/100\nآخرین قیمت: ${fmt(s.last)} ریال\nRSI: ${ind.rsi.roundToInt()} | ASI: ${String.format(Locale.US,"%.1f",ind.asi)} | MACD: ${String.format(Locale.US,"%.2f",ind.macd)} | ADX: ${String.format(Locale.US,"%.1f",ind.adx)}\nتحلیل: ${if(score>=72)"روند و مومنتوم صعودی‌تر هستند؛ ورود پله‌ای و حدضرر الزامی است." else if(score<=28)"فشار فروش غالب است؛ از ورود جدید اجتناب شود." else "تأیید کافی وجود ندارد؛ صبر برای شکست/برگشت بهتر است."}"
        AlertDialog.Builder(this).setTitle("تحلیل ${s.symbol}").setMessage(msg).setPositiveButton("باشه",null).setNeutralButton("🔊 پخش صدا"){_,_->speak("سیگنال $sig برای نماد ${s.symbol}. قیمت فعلی ${s.last.roundToInt()} ریال. قدرت سیگنال $score از صد.")}.show()
    }

    private fun update(g:Double,d:Double,o:Double){
        if(g<=0)return; price.text="${fmt(g)} ریال"; history.addLast(g); while(history.size>5000)history.removeFirst(); save(); chart.setData(history.toList())
        val a=history.toList(); val ind=Indicators(a); val technical=ind.score(); val fundamental=fundamentalScore(d,o); val score=((technical*0.70)+(fundamental*0.30)).roundToInt().coerceIn(0,100)
        val newSignal=when{score>=72->"🟢 خرید";score<=28->"🔴 فروش";else->"🟡 صبر"}; val old=signal.text.toString(); signal.text=newSignal
        metrics.text=ind.dashboard()+"\nفاندامنتال: $fundamental/100 | امتیاز نهایی: $score/100"; analyst.text=analystText(ind,score)+"\n\nفاندامنتال: ${fundamental}/100 — دلار و اونس در امتیاز نهایی لحاظ شدند."
        trade.text=tradePlan(g,score,capitalInput.text.toString().filter{it.isDigit()}.toDoubleOrNull()?:10_000_000.0)
        backtest.text=backtestText(a); watch.text="طلا ۱۸: ${fmt(g)} ریال\nدلار آزاد: ${if(d>0)fmt(d)+" ریال" else "—"}\nاونس طلا: ${if(o>0)String.format(Locale.US,"%.2f $",o) else "—"}\nتعداد نمادهای دیده‌بان: ${allSymbols.size}"
        if(alerts && old!=newSignal && (newSignal.contains("خرید")||newSignal.contains("فروش"))){ speak(tradeVoice(newSignal,g,score,trade.text.toString())); notify("$newSignal طلا ۱۸ | قدرت $score/100") }
    }
    private fun fundamentalScore(d:Double,o:Double):Int{ var s=50; if(o>0)s += if(o>=4000)8 else if(o<2500)-6 else 0; return s.coerceIn(0,100) }
    private fun tradePlan(g:Double,score:Int,capital:Double):String{ val buyLow=g*(if(score>=72)0.995 else 1.0);val buyHigh=g*(if(score>=72)1.002 else 1.0);val t1=g*(1+if(score>=72)0.022 else 0.012);val t2=g*(1+if(score>=72)0.045 else 0.022);val sl=g*(1-if(score>=72)0.015 else 0.010);val direction=when{score>=72->"خرید";score<=28->"فروش/عدم ورود";else->"صبر"};val p1=capital*(t1/buyHigh-1);val p2=capital*(t2/buyHigh-1);val loss=capital*(1-sl/buyHigh);return "سناریو: $direction\nقیمت فعلی: ${fmt(g)} ریال\n📥 ورود پیشنهادی: ${fmt(buyLow)} تا ${fmt(buyHigh)} ریال\n🎯 هدف ۱: ${fmt(t1)} | سود تقریبی: ${fmtToman(p1)}\n🎯 هدف ۲: ${fmt(t2)} | سود تقریبی: ${fmtToman(p2)}\n🛑 حد ضرر: ${fmt(sl)} | زیان تقریبی: ${fmtToman(loss)}\n📊 قدرت: $score/100\n⚠️ سناریویی است و تضمین سود نیست."}
    private fun fmtToman(x:Double)="${String.format(Locale.US,"%,.0f",max(0.0,x))} تومان"
    private fun tradeVoice(sig:String,g:Double,score:Int,plan:String)="هشدار $sig طلای هجده عیار صادر شد. قدرت سیگنال $score از صد. ${plan.replace("\n",". ")}"
    private fun fetchNews(){Thread{try{val titles=readRss("https://news.google.com/rss/search?q=gold+Iran+dollar+Fed&hl=fa&gl=IR&ceid=IR:fa");val scored=titles.take(8).map{t->val neg=listOf("کاهش","ریزش","فروش","افزایش نرخ","تحریم جدید").count{t.contains(it)};val pos=listOf("افزایش","رشد","صعود","کاهش نرخ","تقاضا").count{t.contains(it)};Triple(t,pos-neg,if(pos>neg)"مثبت" else if(neg>pos)"منفی" else "خنثی")};runOnUiThread{news.text=if(scored.isEmpty())"خبر قابل دریافت نیست." else scored.joinToString("\n\n"){"${it.third}: ${it.first}"}+"\n\nمنبع: Google News RSS"}}catch(e:Exception){}}}.start()}
    private fun readRss(u:String):List<String>{val c=URL(u).openConnection() as HttpURLConnection;c.connectTimeout=10000;c.readTimeout=10000;c.setRequestProperty("User-Agent","Mozilla/5.0");val parser=XmlPullParserFactory.newInstance().newPullParser();parser.setInput(c.inputStream,"UTF-8");val out=mutableListOf<String>();var ev=parser.eventType;var inTitle=false;while(ev!=org.xmlpull.v1.XmlPullParser.END_DOCUMENT){if(ev==org.xmlpull.v1.XmlPullParser.START_TAG&&parser.name=="title")inTitle=true else if(ev==org.xmlpull.v1.XmlPullParser.TEXT&&inTitle&&parser.text.isNotBlank()){out.add(parser.text.trim());inTitle=false};ev=parser.next()};return out.drop(1)}
    private fun analystText(i:Indicators,score:Int):String{val regime=when{ i.adx>=25&&i.ema9>i.ema21->"روند صعودی قدرتمند";i.adx>=25->"روند نزولی قدرتمند";else->"بازار کم‌روند/نوسانی"};return "امتیاز ترکیبی: $score/100 | رژیم بازار: $regime\nEMA: ${if(i.ema9>i.ema21)"مثبت" else "منفی"} • RSI=${i.rsi.roundToInt()} • MACD=${String.format(Locale.US,"%.2f",i.macd)} • ADX=${String.format(Locale.US,"%.1f",i.adx)} • ASI=${String.format(Locale.US,"%.1f",i.asi)}\n${when{score>=72->"نتیجه: شرایط ورود بالقوه؛ ورود پله‌ای و حدضرر الزامی.";score<=28->"نتیجه: فشار فروش/ریسک بالاست؛ از ورود جدید اجتناب کن.";else->"نتیجه: سیگنال قطعی نیست؛ منتظر تأیید بمان."}}"}
    private fun backtestText(a:List<Double>):String{if(a.size<60)return "تاریخچه: ${a.size}/60 نمونه. برای بک‌تست معنادار حداقل ۶۰ نمونه لازم است.";var n=0;var w=0;var total=0.0;for(k in 30 until a.size-4){val s=Indicators(a.subList(0,k+1)).score();if(s>=72||s<=28){n++;val e=a[k];val f=a.subList(k+1,min(a.size,k+5));val r=if(s>=72)(f.maxOrNull()!!/e-1)*100 else(e/f.minOrNull()!!-1)*100;total+=r;if(r>0.15)w++}};return "معاملات: $n | موفق: $w | دقت: ${if(n==0)0 else String.format(Locale.US,"%.1f",w*100.0/n)}% | بازده تجمعی: ${String.format(Locale.US,"%.2f",total)}%"}
    private fun fmt(x:Double)=String.format(Locale.US,"%,.0f",x)

    private fun save(){getPreferences(0).edit().putString("h",history.joinToString(",")).apply()}
    private fun load(){getPreferences(0).getString("h","")?.split(",")?.mapNotNull{it.toDoubleOrNull()}?.takeLast(5000)?.forEach{history.addLast(it)}}
    private fun saveCatalog(xs:List<MarketSymbol>){getPreferences(0).edit().putString("catalog",JSONArray().apply{xs.forEach{put(JSONObject().apply{put("c",it.code);put("s",it.symbol);put("n",it.name);put("l",it.last);put("p",it.close);put("x",it.pct);put("v",it.volume);put("q",it.value)})}}.toString()).apply()}
    private fun loadCatalog():List<MarketSymbol>{return try{val a=JSONArray(getPreferences(0).getString("catalog","[]"));List(a.length()){i->val x=a.getJSONObject(i);MarketSymbol(x.getString("c"),x.getString("s"),x.getString("n"),x.getDouble("l"),x.getDouble("p"),x.getDouble("x"),x.getDouble("v"),x.getDouble("q"))}}catch(_:Exception){emptyList()}}
    private fun saveSymbolHistory(code:String,vals:List<Double>){getPreferences(0).edit().putString("hist_$code",vals.joinToString(",")).apply()}
    private fun loadSymbolHistory(code:String):List<Double>{return getPreferences(0).getString("hist_$code","")?.split(",")?.mapNotNull{it.toDoubleOrNull()}?.takeLast(5000)?:emptyList()}
    private fun get(u:String):String{val c=URL(u).openConnection() as HttpURLConnection;c.connectTimeout=15000;c.readTimeout=15000;c.setRequestProperty("User-Agent","Mozilla/5.0");c.setRequestProperty("Accept","application/json,text/html,*/*");return c.inputStream.bufferedReader().use{it.readText()}}
    private fun extract(h:String,key:String):Double?{val i=h.indexOf(key,true);if(i<0)return null;val s=h.substring(i,min(h.length,i+2500));for(p in listOf("data-value=\\\"([0-9.]+)\\\"","value[^0-9]{0,60}([0-9]{6,15})","([0-9]{6,15})")){Regex(p).find(s)?.groupValues?.get(1)?.toDoubleOrNull()?.let{return it}};return null}
    private fun initTts(){tts=TextToSpeech(this){st->if(st==TextToSpeech.SUCCESS)tts?.language=Locale("fa","IR")}}
    private fun speak(s:String){if(alerts)tts?.speak(s,TextToSpeech.QUEUE_FLUSH,null,"signal-${System.currentTimeMillis()}")}
    private fun channel(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"),77);if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("sig","سیگنال",NotificationManager.IMPORTANCE_DEFAULT))}
    private fun notify(s:String){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED)return;getSystemService(NotificationManager::class.java).notify(7,Notification.Builder(this,"sig").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("طلا نوسان PRO").setContentText(s).setAutoCancel(true).build())}
    private fun checkForPlayUpdate(){try{val m=AppUpdateManagerFactory.create(this);m.appUpdateInfo.addOnSuccessListener{info->if(info.updateAvailability()==UpdateAvailability.UPDATE_AVAILABLE&&info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)){m.startUpdateFlowForResult(info,AppUpdateType.IMMEDIATE,this,9101)}}}catch(_:Exception){}}

    data class MarketSymbol(val code:String,val symbol:String,val name:String,val last:Double,val close:Double,val pct:Double,val volume:Double,val value:Double)
    class SimpleWatcher(val fn:(String)->Unit):android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){fn(s?.toString() ?: "")};override fun afterTextChanged(e:android.text.Editable?){}}
    class Indicators(private val a:List<Double>){
        val rsi:Double=getRSI(14);val ema9:Double=ema(9);val ema21:Double=ema(21);val sma20:Double=sma(20);val macd:Double=ema(12)-ema(26);val signalLine:Double=ema(9);val bbMid:Double=sma20;val bbStd:Double=std(20);val upper:Double=bbMid+2*bbStd;val lower:Double=bbMid-2*bbStd;val atr:Double=avgAbsMove(14);val adx:Double=adx14();val stoch:Double=stoch14();val obv:Double=obvProxy();val asi:Double=asiProxy()
        fun score():Int{if(a.size<30)return 50;var s=50;if(ema9>ema21)s+=12 else s-=12;if(rsi<30)s+=18 else if(rsi>70)s-=18 else if(rsi>55)s+=6 else if(rsi<45)s-=6;if(macd>0)s+=8 else s-=8;if(adx>25)s+=if(ema9>ema21)7 else -7;if(a.last()<lower)s+=8 else if(a.last()>upper)s-=8;if(stoch<20)s+=7 else if(stoch>80)s-=7;return s.coerceIn(0,100)}
        fun dashboard()="RSI: ${rsi.roundToInt()} | ASI: ${"%.1f".format(Locale.US,asi)}\nEMA9: ${fmt(ema9)} | EMA21: ${fmt(ema21)} | SMA20: ${fmt(sma20)}\nMACD: ${"%.2f".format(Locale.US,macd)} | Signal: ${"%.2f".format(Locale.US,signalLine)}\nBollinger: ${fmt(lower)} — ${fmt(upper)} | ATR: ${fmt(atr)}\nADX: ${"%.1f".format(Locale.US,adx)} | Stoch: ${"%.1f".format(Locale.US,stoch)} | OBV*: ${"%.0f".format(Locale.US,obv)}"
        private fun fmt(x:Double)=String.format(Locale.US,"%,.0f",x);private fun sma(n:Int)=a.takeLast(min(n,a.size)).average();private fun ema(n:Int):Double{if(a.isEmpty())return 0.0;val k=2.0/(n+1);var e=a.take(min(n,a.size)).average();for(v in a.drop(min(n,a.size)))e=v*k+e*(1-k);return e};private fun std(n:Int):Double{val x=a.takeLast(min(n,a.size));val m=x.average();return sqrt(x.sumOf{(it-m).pow(2)}/x.size)};private fun avgAbsMove(n:Int):Double{val x=a.takeLast(min(n+1,a.size));if(x.size<2)return 0.0;return(1 until x.size).map{abs(x[it]-x[it-1])}.average()};private fun getRSI(n:Int):Double{val x=a.takeLast(min(n+1,a.size));if(x.size<2)return 50.0;var up=0.0;var dn=0.0;for(k in 1 until x.size){val d=x[k]-x[k-1];if(d>0)up+=d else dn-=d};if(dn==0.0)return 100.0;val rs=up/dn;return 100-100/(1+rs)};private fun stoch14():Double{val x=a.takeLast(min(14,a.size));val lo=x.minOrNull()?:0.0;val hi=x.maxOrNull()?:1.0;return if(hi==lo)50.0 else(a.last()-lo)/(hi-lo)*100};private fun adx14():Double{if(a.size<16)return 0.0;val x=a.takeLast(15);val moves=(1 until x.size).map{abs(x[it]-x[it-1])};val avg=moves.average();if(avg==0.0)return 0.0;val directional=abs(x.last()-x.first())/moves.sum()*100;return(directional*0.7+25*0.3).coerceIn(0.0,100.0)};private fun obvProxy():Double{var v=0.0;for(k in 1 until a.size)v+=when{a[k]>a[k-1]->1.0;a[k]<a[k-1]->-1.0;else->0.0};return v};private fun asiProxy():Double{var v=0.0;for(k in 1 until a.size){val ch=(a[k]-a[k-1])/max(1e-9,a[k-1])*100;v+=ch.coerceIn(-10.0,10.0)};return v}}
    class PriceChart(c:Context):View(c){private var d:List<Double> = emptyList();private val p=Paint(1);fun setData(x:List<Double>){d=x;invalidate()};override fun onDraw(c:Canvas){super.onDraw(c);if(d.size<2)return;p.style=Paint.Style.STROKE;p.strokeWidth=4f;p.color=Color.rgb(60,90,160);val lo=d.minOrNull()!!;val hi=d.maxOrNull()!!;val den=max(hi-lo,1e-9);val path=Path();d.forEachIndexed{i,v->val x=20+i*(width-40f)/(d.size-1);val y=height-20-((v-lo)/den)*(height-40);if(i==0)path.moveTo(x,y.toFloat())else path.lineTo(x,y.toFloat())};c.drawPath(path,p)}}
}
