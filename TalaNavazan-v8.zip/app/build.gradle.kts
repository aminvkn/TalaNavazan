plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "ir.talanavazan.app"; compileSdk = 35
    defaultConfig { applicationId = "ir.talanavazan.app"; minSdk = 26; targetSdk = 35; versionCode = 8; versionName = "2.0.0" }
}


dependencies { implementation("com.google.android.play:app-update:2.1.0") }
